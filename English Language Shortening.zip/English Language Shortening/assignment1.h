/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/file.h to edit this template
 */

/* 
 * File:   assignment1.h
 * Author: JACKI
 *
 * Created on September 18, 2024, 7:52 a.m.
 */

#ifndef ASSIGNMENT1_H
#define ASSIGNMENT1_H

#ifdef __cplusplus
extern "C" {
#endif

    /*
     * Main function that handles game mechanics
     */
    int game(char maze[50][50]);
    
    /*
     * Function to move player the player around the maze
     */
    int playerMove(char maze[50][50]);

    /*
     * Takes the next object the player will face and returns the score value of 
     * the object to add to the player score
     */
    int addScore(char object);    
    
    /*
     * Returns the custom datatype movements
     * Function changes movements.direction depending on the inputted key
     */
    struct movements inputDirection(char direction);
    
    int checkWin();
    
    /*
     * for loop to print each row of the maze
     */
    int printMaze();

    /*
     * Finds where the player is positioned
     */
    struct movements findLocation(char maze[50][50]);

    /*
     * resets player.direction to {0,0}
     * Used at the start of the main() while loop to reset player vector
     */
    struct movements reset(struct movements direction);

    /*
     * Stops the game
     */
    int quit();

    /*
     * Prints a greeting for the user
     */
    int greeting(char maze[50][50]);

    /*
     * Defines a data type with two values
     * Direction(array) determines the movement vector 
     * Character(char) determines the player character's sprite(V)
     */
    struct movements {
        int directions[2];
        int location[2];
        int playerScore;
        char character;
    };

#ifdef __cplusplus
}
#endif

#endif /* ASSIGNMENT1_H */

