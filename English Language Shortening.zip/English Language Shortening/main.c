/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/cFiles/main.c to edit this template
 */

/* 
 * File:   main.c
 * Author: JACKI
 *
 * Created on September 17, 2024, 1:55 p.m.
 */

#include <stdio.h>
#include <stdlib.h>
#include "assignment1.h"

struct movements player;
int mazesize[2]; //size of 2d maze according to file

int main(int argc, char** argv) {
    FILE *mazefile;
    mazefile = fopen("C:/Users/JACKI/Desktop/Coding 2024/assignments/mazes/Maze1.txt",
            "r");
    static char maze[50][50];
    int gamestate = 0;
    
    //Gets the first two lines of the file for dimensions of mazee
    char c;
    char line[4];
    if (fgets(line, sizeof (line), mazefile) != NULL) {
        mazesize[0] = atoi(line);
    }
    if (fgets(line, sizeof (line), mazefile) != NULL) {
        mazesize[1] = atoi(line);
    }

    //Organizing file into 2d maze array
    if (mazefile) {
        int row = 0;
        int column = 0;
        while (fscanf(mazefile, "%c", &c) != EOF) {
            if (c != '\n') {
                maze[row][column] = c;
                column++;
            }
            if (maze[row][column] == '\n') {
                column = 0;
                row++;
            }
        }
        fclose(mazefile);
    } else {
        printf("%s", "Not a valid file");
    }//

    //start of game
    greeting(maze);
    player = findLocation(maze);
    //Game loop
    while (gamestate == 0) {
        gamestate = game(maze);
    }
    return (EXIT_SUCCESS);
}//main

/*
 * Contains the game components. 
 * Has prints for instructions and responses to player moves
 * Calls inputDirection() for movement vector and playerMove() to update player
 */
int game(char maze[mazesize[0]][mazesize[1]]) {
    int gamestate = 0;
    char userchoice; //char the user input will be stored here
    player = reset(player);//resets player vector to (0,0)
    printf("\n%s", "Enter direction Up(u), Down(d), Left(l), Right(r): ");
    fflush(stdout);
    scanf("%c", &userchoice);
    printf("%c", userchoice);
    fflush(stdin);

    //if user decides to quit
    if (userchoice == 'q' || userchoice == 'Q') {
        quit();
        return 1;
        ;
    }

    player = inputDirection(userchoice);//sets the player's movement vector
    gamestate = playerMove(maze);//moves player and also check for win

    printMaze(maze);
    printf("\n%s", "Current score is: ");
    printf("%i", player.playerScore);

    return gamestate;
}//game()

/*
 *Determines direction of movement
 *Depending on input, returns an array which determines direction of movement
 */
struct movements inputDirection(char direction) {

    if (direction == 'U' || direction == 'u') {//move up
        printf("\n%s", "Moving up...\n");
        player.directions[0] = -1;
        player.character = 'v';
        return (player);
    } else if (direction == 'L' || direction == 'l') {//move left
        printf("\n%s", "Moving left...\n");
        player.directions[1] = -1;
        player.character = '>';
        return (player);
    } else if (direction == 'R' || direction == 'r') {//move right
        printf("\n%s", "Moving right...\n");
        player.directions[1] = 1;
        player.character = '<';
        return (player);
    } else if (direction == 'D' || direction == 'd') {//move down
        printf("\n%s", "Moving down...\n");
        player.directions[0] = 1;
        player.character = '^';
        return (player);
    } else {//invalid input  
        printf("\n%s", "Invalid input, try again");
        return (player);
    }
}//inputDirection()

/*
 * Moves the player char to the next location and adds points depending on 
 * where it lands.
 * Also checks for walls
 * Checks for exit by calling checkWin()
 */
int playerMove(char maze[mazesize[0]][mazesize[1]]) {
    int gamestate = 0;
    //deletes the player's last location
    maze[player.location[0]][player.location[1]] = ' ';
    //sets the player's next location if next location is not a wall
    if (maze[player.location[0] + player.directions[0]][player.location[1]
            + player.directions[1]] != '-') {

        //Player score is calculated
        player.playerScore += addScore(maze[player.location[0]
                + player.directions[0]][player.location[1] + player.directions[1]]);

        //Player is moved
        maze[player.location[0] + player.directions[0]]
                [player.location[1] + player.directions[1]] = player.character;
        
        //Player location is updated
        player.location[0] += player.directions[0];
        player.location[1] += player.directions[1];
        gamestate = checkWin(); //checks if the player has exited the maze
        return gamestate;
    } else {//player does not move if theres wall in the way
        maze[player.location[0]][player.location[1]] = player.character;
        printf("\n%s", "Next location is a wall, try again\n");
        return 0;
    }
}//playerMove()

/*
 * Return score to be added depending on what the player lands on
 */
int addScore(char object) {
    static int score;

    if (object == ' ') {//empty space
        score = -1;
        return score;
    } else if (object == '.') {//cookie
        score = 2;
        return score;
    } else if (object == 'C') {//cherry
        score = 10;
        return score;
    } else {
        score = 0;
        return score;
    }
}//addScore

/*
 * Checks whether the player has reached the edge of the maze
 */
int checkWin() {
    if (player.location[0] <= 0 || player.location[0] >= mazesize[0]) {
        printf("\n%s", "Game Over! Score:");
        printf("%i", player.playerScore);
        return 1;
    } else if (player.location[1] <= 0 || player.location[1] >= mazesize[1]) {
        printf("\n%s", "Game Over! Score:");
        printf("%i", player.playerScore);
        return 1;
    } else
        return 0;
}//checkWin()

/*
 prints maze by going through each row and column of the maze array
 */
int printMaze(char maze[mazesize[0]][mazesize[1]]) {
    for (int row = 0; row < mazesize[0]; row++) {
        printf("\n");//prints new line for each row
        for (int column = 0; column < mazesize[1]; column++) {
            printf("%c", maze[row][column]);
        }
    }
    return (EXIT_SUCCESS);
}//printMaze

/*
 * Finds the location of the player and sets the player location
 */
struct movements findLocation(char maze[mazesize[0]][mazesize[1]]) {
    //runs through entire maze for the player char
    for (int row = 0; row < mazesize[0]; row++) {
        for (int column = 0; column < mazesize[1]; column++) {
            if (maze[row][column] == '<' || maze[row][column] == '>'
                    || maze[row][column] == '^' || maze[row][column] == 'V') {
                player.location[0] = row;
                player.location[1] = column;
            };
        }
    }
    return player;
}//findLocation()

/*
 * Resets the player's vector to 0,0
 */
struct movements reset(struct movements player) {
    player.directions[0] = 0;
    player.directions[1] = 0;
    return player;
}//reset()

/*
 * Closes the game and resets score
 */
int quit() {
    player.playerScore = 0;
    printf("\n%s", "Game Over! Score:");
    printf("%i", player.playerScore);
    return 0;
}//quit()

/*
 * Sends a greeting to the player at game start and prints maze
 */
int greeting(char maze[mazesize[0]][mazesize[1]]) {
    printf("%s", "========================================"
            "\nJackie's Maze Extravaganza!"
            "\nCookie Crumb: +2 pts; Cherry: +10pts; Space: -1pts"
            "\n========================================");
    printMaze(maze);
    return 0;
}//greeting()
